from google.oauth2 import service_account
from googleapiclient.discovery import build
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials
import io
from googleapiclient.errors import HttpError
import os
from sys import argv
from BIB_API import drive_ls, folder_po_id , drive_ls, createRemoteFolder , spisok_fails_roditelya ,copi_files,nev_json_autoriz
import subprocess

smena_limit = 0
json_nomber = 0

mud_id=argv[1] # айди диска 
mud_name=argv[2] # имя диска 
nnn=argv[3] # имя папки

SCOPES = ["https://www.googleapis.com/auth/drive",
          "https://www.googleapis.com/auth/cloud-platform",
          "https://www.googleapis.com/auth/iam"]

credentials = Credentials.from_authorized_user_file('token.json', SCOPES)
service = build('drive', 'v3', credentials=credentials)
service2 = build('drive', 'v2', credentials=credentials)

#if len(drive_ls(service)) == 1 :
#   mud_id=drive_ls(service)[0]['id']
#   mud_name=drive_ls(service)[0]['name']
mud=mud_id
#else:
#   print( 'НЕ пойму какого хрена вижу больше одного диска ') 
#   exit()

#print([eee.get('name') for eee in folder_po_id(service,mud,mud)])
#nnn=input('ВВЕДИ ИМЯ ОСНОВНОЙ ПАПКИ С БЕКАПАМИ : ')

path = 'accounts'

process = subprocess.Popen(['python3', 'fulsmena.py', f'{mud}']) 
process.wait() # подготовка к копированию

rezp=False
for sps in folder_po_id(service,mud):  ## Нашли клонируемую или создали
   name_vsfold = sps.get('name')
   if name_vsfold == nnn :
      iskoma=sps
   if name_vsfold == nnn+'-copy' :
      razn_fold_id = sps.get('id')
      rezp=True

if rezp != True:
   razn_fold_id=createRemoteFolder(service2, nnn+'-copy', mud)

print(razn_fold_id)
#print(iskoma)
ls_id_nado=folder_po_id(service,mud,iskoma['id'])# все папки в исходной

print(ls_id_nado)
for nnk in ls_id_nado:
   sozdan=False
   for provfo in spisok_fails_roditelya(razn_fold_id,mud,service):
      #print(provfo)
      if provfo['name'] == nnk['name'] :
         vcopy_fold_id=provfo['id']
         print('suchestvuet')
         sozdan=True
   if sozdan != True :
      vcopy_fold_id=createRemoteFolder(service2, nnk['name'], razn_fold_id)


   ls_is=spisok_fails_roditelya(nnk['id'],mud,service) # Список всех файлов В указанной папке исходник 
   spp1=[eee.get('name') for eee in ls_is ]
   ls_naz=spisok_fails_roditelya(vcopy_fold_id,mud,service) # Список всех файлов В указанной папке Назначение
   spp2=[eee.get('name') for eee in ls_naz ]

   print(len(ls_is))
   print(len(ls_naz))

   lsr=list(set(spp1)-set(spp2))
   print('plan copy '+str(len(lsr)))
   ls=[]
   for i in ls_is:
    spp0=i.get('name')
    if spp0 in lsr:
        ls.append(i)  # Список с разницей



   for coi_os in ls:
      josh_limit=0
      while True:
         json_nomber=json_nomber+1
         if json_nomber >= 101 :
            json_nomber = 1
         service = nev_json_autoriz(json_nomber,SCOPES)
         pez_copy=copi_files(service,coi_os['id'],vcopy_fold_id)
         print(pez_copy)
         if pez_copy == 'cannotCopyFile' or pez_copy == 'uspeh' or pez_copy == 'notFound' :
            break
         elif josh_limit == 100:
            print('Menyaem')
            print('ПОРА ПЕРЕЕЗЖАТЬ подготовь новый диск: ')
            for eee in drive_ls(service):
               if eee['id'] == mud_id:
                   mud_osn = eee
            mud_id=mud_osn['id']
            mud_name=mud_osn['name']
            processn = subprocess.Popen(['python3', 'pereezd.py', f'{mud_id}', f'{mud_name}'], stdout=subprocess.PIPE) 
            process = subprocess.Popen(['python3', 'pot_dell.py', f'{mud_id}']) 

            mud_id=str(str(processn.stdout.read()[-20:-1]))[2:-1]
            print('new drive - '+ str(mud_id))
            process = subprocess.Popen(['python3', 'fulsmena.py', f'{mud_id}']) 
            process.wait() # 
            print('ZAmenya Uspeh')
            smena_limit+=1
         elif pez_copy == 'userRateLimitExceeded':
            print('schet')
            josh_limit+=1
         elif smena_limit == 15:
            print('MNOGO POPITOK')
            exit()
         else:
            print(pez_copy)



